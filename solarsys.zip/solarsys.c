//Solar System in OpenGL
//M. Bhagya Sree(20MCME01) and S. Anusri (20MCME31)
#include<GL/glut.h>
#include<math.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define PI 3.141592653589


void ellipse(float r, float e)
{
    glColor3f(1.0, 1.0, 1.0);
    glPushMatrix();
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < 360; i++) {
        float theta = i * PI / 180.0;
        float a = r * cos(theta);
        float b = e * r * sin(theta);
        glVertex3f(a , b , 0.0);
    }
    glEnd();
    glPopMatrix();
}


void planet(float d, float radius, float aspeed, float rotangle, float e, char * texture_file)
{
    glPushMatrix();    
    float angle = (GLfloat) (glutGet(GLUT_ELAPSED_TIME) * aspeed) / d;
    float x = d*cos(angle);
    float y = d*e*sin(angle);
    angle = (GLfloat) (glutGet(GLUT_ELAPSED_TIME) * aspeed);
    glTranslatef(x, y, 0.0);
    glRotatef(angle, 0.0, 1.0, 0.0);
    glRotatef(rotangle, 0.0, 0.0, 1.0);
    int width, height, nrChannels;
    unsigned char *data = stbi_load(texture_file, &width, &height, &nrChannels, 0);

    glEnable(GL_TEXTURE_2D);
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glPushMatrix(); // Push matrix for planet's rotation
    glRotatef(glutGet(GLUT_ELAPSED_TIME) * aspeed, 0.0, 0.0, 1.0); // Rotate around its own axis
    GLUquadricObj *quadric = gluNewQuadric();
    gluQuadricTexture(quadric, GL_TRUE);      //Code for the textured Sphere
    gluSphere(quadric, radius, 30, 30);
    gluDeleteQuadric(quadric);
    glPopMatrix(); // Pop matrix for planet's rotation

    stbi_image_free(data);
    glDisable(GL_TEXTURE_2D);
    glPopMatrix();
}


void drawRings(float d, float innerRadius, float outerRadius, float aspeed,float angle) {
    glPushMatrix();
    glColor3f(1.0, 0.5, 0.2);   
    float a = (GLfloat) glutGet(GLUT_ELAPSED_TIME) * aspeed / d;
    float x = 150*cos(a);
    float y = 150*0.5*sin(a);
    glTranslatef(x, y, 0.0);
    glRotatef((GLfloat) glutGet(GLUT_ELAPSED_TIME) * aspeed, 0.0, 1.0, 0.0);
     glRotatef(angle, 0.0, 0.0, 1.0);
    glutWireTorus(innerRadius, outerRadius, 32, 32);
    glPopMatrix();
}

void Solar()
{     
   //Sun
   char* texture_file = "sun_texture.jpg";
   planet(1.0, 9, 0.05, 0.0, 0.0, texture_file);
   //Mercury
   texture_file = "mercury_texture.jpg";
   static GLfloat mer = 0.0;
   ellipse(35, 0.3);
   glColor3f(0.7, 0.7, 0.7);
   planet(35, 2.0,0.5, mer,0.3, texture_file);
   mer += 1.0;
   //Venus
   texture_file = "venus_texture.jpg";
   static GLfloat ven = 0.0;
   ellipse(45, 0.35);
   glColor3f(1.0, 1.0, 0.0);
   planet( 45, 4.0, 0.02, ven, 0.35, texture_file);
   ven += 0.5;
   //Earth
   texture_file = "earth_texture.jpg";
   static GLfloat ear = 0.0;
   ellipse(60, 0.4);
   planet(60, 5.0, 0.015, ear, 0.4, texture_file);
   ear += 0.3;
   //Mars
   texture_file = "mars_texture.jpg";
   static GLfloat mar = 0.0;
   ellipse(80, 0.45);
   glColor3f(1.0, 0.0, 0.0);
   planet( 80, 3.0, 0.01, mar, 0.45, texture_file);
   mar += 0.2;
   //Jupiter
   texture_file = "jupiter_texture.jpg";
   static GLfloat jup = 0.0;
   ellipse(120, 0.45);
   glColor3f(0.72, 0.45, 0.20);
   planet(120, 10.0, 0.005, jup, 0.45, texture_file);
   jup += 0.1;
   //Saturn
   texture_file = "saturn_texture.jpg";
   static GLfloat sat = 0.0;
   ellipse(150, 0.5);
   glColor3f(0.137255, 0.419608, 0.556863);
   planet(150, 8.0, 0.003, sat, 0.5, texture_file);
   drawRings(150, 1.0, 12.0,0.003, sat);
   sat += 0.05;
   //Uranus
   texture_file = "uranus_texture.jpg";
   static GLfloat ura = 0.0;
   ellipse(170, 0.5);
   glColor3f(0.0, 0.5, 0.5);
   planet(170, 4.0, 0.002, ura, 0.5, texture_file);
   ura += 0.03;
   //Neptune
   texture_file = "neptune_texture.jpg";
   static GLfloat nep = 0.0;
   ellipse(190, 0.55);
   glColor3f(0.0, 0.0, 1.0);
   planet(190, 6.0, 0.0015, nep,0.55, texture_file);
   nep += 0.02;
}



void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(0.0, 0.0, 0.0, 0.0);
    Solar();
    glutSwapBuffers();
}


void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(90.0, (GLfloat)w/(GLfloat)h, 1.0, 200.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 200.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void init(void) {
    glEnable(GL_DEPTH_TEST);
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowPosition(0, 0);                  
    glutInitWindowSize(1000, 1000);
    glutCreateWindow("Solar System in OpenGL");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
